<h1>author.php - Das Autoren-Detail</h1>
<p>
  Dieses Template listet Detail-Infos zum Autor. Klickt ein Leser beispielsweise auf den Namen eines Autoren, wird dieses Template bevorzugt gewählt
</p>