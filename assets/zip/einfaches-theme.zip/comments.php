<h1>comments.php - Die Kommentar-Funktion</h1>
<p>Diese Datei wird automatisch aufgerufen, wenn die Funktion get_comments() innerhalb eines Templates aufgerufen wurde. </p>