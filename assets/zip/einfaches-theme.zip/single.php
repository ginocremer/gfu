<h1>single.php - Dies ist die Detail-Seite eines einzelnen Beitrages</h1>
<p>
  Dieses Template kann genau wie die Datei page.php durch spezifischere Templates "übergangen" werden, z.B. single-2.php für den Beitrag mit der ID 2. 
</p>