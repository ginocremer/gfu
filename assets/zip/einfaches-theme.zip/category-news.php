<h1>category-news.php: Spezifisches Template für das Kategorie-Archiv "News"</h1>
<p>
  Wird ein Kategorie-Archiv aufgerufen, sucht WordPress erstmal nach der spezifischsten Template-Datei. 
  Ist beispielsweise ein Beitrag der Kategorie "News" zugeordnet, sucht WordPress bevorzugt nach der Datei category-news.php.
  Ist das Template nicht vorhanden, wird die allgemeinere Datei "category.php" genommen. Ist auch diese nicht vorhanden, wird
  die noch allgemeinere Datei archive.php genommen. 
</p>