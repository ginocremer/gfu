<aside>
  sidebar.php: Diese Datei wird aufgerufen wenn irgendwo die Funktion get_sidebar() aufgerufen wurde. 
</aside>