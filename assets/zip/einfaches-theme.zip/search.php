<h1>search.php: Such-Resultate</h1>
<p>
  Dieses Template wird aufgerufen wenn eine Suche in WordPress durchgeführt wurde. Hier findet also die Auflistung der Suchresultate statt.
</p>