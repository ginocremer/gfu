<h1>category.php - Die Kategorie-Übersicht</h1>
<p>
  Dieses Template bildet die Archiv-Ansicht einer Kategorie und gilt allgemein damit für alle Kategorie-Auflistungen.
  Ruft beispielsweise jemand die Kategorie "Allgemein" auf, wird dieses Template aufgerufen um die Beiträge zu listen.
  Ist dieses Template nicht vorhanden, sucht WordPress die Datei archiv.php als allgemeineres Template
</p>