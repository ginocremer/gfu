<h1>page.php - Ich bin eine ganz normale Seite</h1>
<p>
  Dieses Template ist ein Fallback für alle Seiten. Es kann natürlich mit einem spezifischeren Seiten-Template wie page-1.php übergangen werden. 
</p>