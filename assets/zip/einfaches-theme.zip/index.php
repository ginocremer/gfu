<h1>Index.php - Dies ist die Haupt-Datei</h1>
<p>
  Die index.php ist die wichtigste Datei. Sie wird benötigt, damit überhaupt das Theme aktiviert werden kann. 
  Sie bildet das letzte Rückgrat: Sind spezifischere Templates nicht vorhanden, wird in letzter Instanz immer die
  index.php aufgerufen. Ein Theme mit nur einem einzigen Template kann streng genommen auch nur mit
  dieser einen Datei betrieben werden (in der Praxis allerdings schwierig).
</p>