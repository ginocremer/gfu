  <p>Dieser Text steht in der Datei footer.php</p>  
  <?php wp_footer(); // Wichtig damit Plugins sich in den Footer einhaken können ?>
  </body>
</html>