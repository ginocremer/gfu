<h1>archive.php - Ich bin eine Archiv-Ansicht</h1>
<p>
  Diese Ansicht wird meist genutzt um ein Beitrags-Archiv mit zahlreichen Beitragen zu listen. Sie dient zudem als Fallback, falls beispielsweise die Datei category.php als spezifischeres Template nicht existiert
</p>