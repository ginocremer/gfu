<aside>
  sidebar-bottom.php: In WordPress ist man keineswegs auf die einzelne Datei sidebar.php angewiesen. Mit der Funktion get_sidebar('bottom')
  wird automatisch diese spezifischere Datei sidebar-bottom.php aufgerufen. Die Namenswahl ist beispielhaft. Mit get_sidebar('inhalt') könnte man zum Beispiel die Datei sidebar-inhalt.php aufrufen. 
</aside>