<?php
  /*
   * Die Datei functions.php funktioniert genau wie ein Plugin. Die Funktionen und Inhalte werden als allererstes geladen im Theme
   *
   */