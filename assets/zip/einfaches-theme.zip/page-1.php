<h1>page-1.php - Ich bin eine Seite nur für die Seite mit der ID 1</h1>
<p>
Wenn die Seite mit der ID 1 in WordPress existiert, werde ich bevorzugt geladen. Ansonsten die page.php Datei. Existiert diese auch nicht, nehme ich halt die index.php
</p>