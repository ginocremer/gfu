<?php
if ( function_exists('register_sidebar') ) { 
	register_sidebar(array(
		'id' => 'kopfleiste',
		'name' => 'Kopfleiste',
		'description' => 'Diese Leiste wird oben auf der Website angezeigt',
 		'before_widget' => '<div class="kopf-item">',
 		'after_widget' => '</div>',
 		'before_title' => '<h3>', 
		'after_title' => '</h3>' 	
					)); 
	register_sidebar(array(
		'id' => 'rechte-leiste',
		'name' => 'Rechte Leiste',
		'description' => 'Diese Leiste wird rechts auf der Website angezeigt',
 		'before_widget' => '<div class="rechteleiste-item">',
 		'after_widget' => '</div>',
 		'before_title' => '<h3>', 
		'after_title' => '</h3>' 	
					)); 
	register_sidebar(array(
		'id' => 'fusszeile',
		'name' => 'Fusszeile',
		'description' => 'Diese Leiste bildet den Abschluss der Website',
 		'before_widget' => '<div class="footer-item">',
 		'after_widget' => '</div>',
 		'before_title' => '<h5>', 
		'after_title' => '</h5>' 	
					)); 
}
add_theme_support( 'post-thumbnails' ); 
$args = array(
	'width'         => 1026,
	'height'        => 400,
	'default-image' => get_stylesheet_directory_uri() . '/img/header.jpg',
);
add_theme_support( 'custom-header', $args );