<aside>
        <?php dynamic_sidebar( 'Rechte Leiste' ); ?>
</aside> 
