</div> <!-- #main -->
        </div> <!-- #main-container -->

        <div class="footer-container">
            <footer class="wrapper">
            	<?php dynamic_sidebar( 'Fusszeile' ); ?>
            </footer>
        </div>

        <?php wp_footer(); ?>
    </body>
</html>
