<!DOCTYPE html>
<html class="no-js">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <title><?php bloginfo('name') ?></title>
        <meta name="description" content="<?php bloginfo('description') ?>">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <link rel="stylesheet" href="<?php echo get_stylesheet_directory_uri(); ?>/style.css">
		<?php wp_head(); ?>
    </head>
    <body>

        <div class="header-container">
            <header class="wrapper clearfix">
                <h1 class="title">
					<a href="<?php bloginfo('url'); ?>">
						<?php bloginfo('name') ?>
					</a>
				</h1>	

                <nav>
                    <?php dynamic_sidebar( 'Kopfleiste' ); ?>
                </nav>
                
            </header>
        </div>
        <div class="main-container">
            <div class="main wrapper clearfix">
            	<img class="header-image" src="<?php header_image(); ?>" alt="" />
