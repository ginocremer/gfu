			<?php get_header(); ?>
				<article>
                	<?php 		
						$args = array( 'post_type' => 'filme' );
						$loop = new WP_Query( $args );
							if ( $loop->have_posts() ) :
								while ( $loop->have_posts() ) : $loop->the_post();
									if ( get_option( 'filmefranzis_settings' ) ) :
										the_post_thumbnail('thumbnail'); 
									endif;
									?>
									<h2><?php the_title();?></h2>
									<?php the_content('Weiterlesen'); 
									?>
									<ul>
										<li><?php 
												$lauflaenge = get_post_meta( $post->ID, 'lauflaenge', true );
												echo "Gesamtspielzeit in Minuten: ".esc_attr($lauflaenge);
											?>
										</li>
										<li><?php 
												$erscheinungsjahr = get_post_meta( $post->ID, 'erscheinungsjahr', true );
												echo "Dieser Film erschien im Jahre: ".esc_attr($erscheinungsjahr);
											?>
										</li>
										<li><?php
											echo get_the_term_list( $post->ID, 'genre', '<strong>Genre: ', ', ', '</strong>' ); 
											?>
										</li>
										<li><?php
											echo get_the_term_list( $post->ID, 'schauspieler', '<strong>Schauspieler: ', ', ', '</strong>' ); 
											?>
										</li>
									</ul>
									<?php
								endwhile;
							endif; 
					?>       
                </article>
            <?php get_sidebar(); ?>
            <?php get_footer(); ?>